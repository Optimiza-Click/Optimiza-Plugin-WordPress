# All in One SEO Pack

Most Downloaded WordPress plugin... almost 30 million downloads

## Help

Read the [documentation](http://semperplugins.com/documentation/)

## Installation

Typically the one-click installer... run bleeding edge coming soon

## Contributing

1. Create your feature branch: `git checkout -b my-new-feature`
2. Commit your changes: `git commit -am 'Add some feature'`
3. Push to the branch: `git push origin my-new-feature`
4. Submit a pull request :D

## Supercharge!

[Upgrade to Pro Version](http://semperplugins.com/plugins/all-in-one-seo-pack-pro-version/)

## Acknowledgements

* Coffee
* Bacon
* Coffee
