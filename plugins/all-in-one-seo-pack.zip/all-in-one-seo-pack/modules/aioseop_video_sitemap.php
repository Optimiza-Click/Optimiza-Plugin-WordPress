<?php

if( AIOSEOPPRO ){
	require_once( AIOSEOP_PLUGIN_DIR . 'pro/video_sitemap.php' );
}